package dev.yorye.FitNessService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitNessServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitNessServiceApplication.class, args);
	}

}
